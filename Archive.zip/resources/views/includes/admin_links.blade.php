<li>
    <a href="{{ url('/admin') }}"><span class="fa fa-comments"></span> Topic of the Day</a>
</li>
<li>
    <a href="{{ url('/admin/topic/add') }}"><span class="fa fa-pencil-square-o"></span> New Topic</a>
</li>
<li>
    <a href="{{ url('/admin/topic/edit') }}"><span class="fa fa-pencil"></span> Edit Topic</a>
</li>
<li>
    <a href="{{ url('/admin/topic/all') }}"><span class="fa fa-calendar"></span> Previous Topics</a>
</li>
<li>
    <a href="{{ url('/admin/user/all') }}"><span class="fa fa-users"></span> All User</a>
</li>
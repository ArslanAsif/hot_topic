@extends('layouts.admin')

@section('content')
    @include('includes.post')
@endsection
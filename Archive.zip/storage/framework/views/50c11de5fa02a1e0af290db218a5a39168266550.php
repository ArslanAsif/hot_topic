<?php $__env->startSection('content'); ?>
    <div>
        <h2><span class="fa fa-calendar"></span> Previous Topics</h2>

        <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                    <th>Sr.#</th>
                    <th>Topic</th>
                    <th>Submitted On</th>
                    <th></th>
                </tr>

                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($topic->id); ?></td>
                    <td><?php echo e($topic->title); ?></td>
                    <td><?php echo e($topic->created_at); ?></td>
                    <td><a href="<?php echo e(url('/admin/topic/view/'.$topic->id)); ?>" class="btn btn-sm btn-default"><span class="fa fa-eye"></span> View</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(isset($topic)): ?>
<div class="wrapper" style="background-color: white; padding: 20px; border-radius: 10px; opacity: 0.9 ">
    <div style="color: black">
        <div id="topic">
            <h2><span class="fa fa-sun-o" style="color: orange"></span> Topic of the Day</h2>
            <h4><?php echo e($topic->title); ?></h4>
        </div>

        <div class="comments">
            <h2><span class="fa fa-comments" style="color: royalblue"></span> Comments <span class="badge"><?php echo e($topic->comments()->count()); ?></span> </h2>

            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="media">
                <div class="media-left">
                    <a href="#">
                        <img class="media-object" src="<?php if($comment->user()->first()->avatar): ?> <?php echo e($comment->user()->first()->avatar); ?> <?php else: ?> <?php echo e(url('/img/dp.png')); ?> <?php endif; ?>" width="40px" alt="Generic placeholder image">
                    </a>
                </div>

                <div class="media-body">
                    <h4 class="media-heading"><?php echo e($comment->user()->first()->name); ?></h4>
                    <?php echo e($comment->comment); ?>


                    </br>
                    <a href="#"><span class="fa fa-thumbs-up"></span> <?php echo e($comment->likes); ?></a>
                    <span>&nbsp;&nbsp;</span>
                    <a href="#"><span class="fa fa-thumbs-down"></span> <?php echo e($comment->dislikes); ?></a>
                    <?php if(Auth::user()): ?>
                        <?php if(Auth::user() == $comment->user()->first() && !Auth::user()->is_admin): ?>
                            <spam>&nbsp;&nbsp;</spam>
                            <a href="<?php echo e(url('/topic/comment/delete/'.$comment->id)); ?>" ><span class="fa fa-trash"></span> Delete Comment</a>
                        <?php endif; ?>

                        <?php if(Auth::user()->is_admin): ?>
                            </br>
                            <a href="<?php echo e(url('/topic/comment/delete/'.$comment->id)); ?>" class="btn btn-sm btn-warning"><span class="fa fa-trash"></span> Delete Comment</a>
                            <?php if(!$comment->user()->first()->is_admin): ?>
                                <a href="<?php echo e(url('/admin/user/ban/'.$comment->user()->first()->id)); ?>" class="btn btn-sm btn-danger"><span class="fa fa-ban"></span><?php if(Auth::user()->ban == 0): ?> Ban User <?php else: ?> Unban User <?php endif; ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            
            <?php echo e($comments->links()); ?>

            
            

            <br>
            <?php if(Auth::guest()): ?>
                <a href="<?php echo e(url('/login')); ?>">Login to post comment</a>
            <?php elseif(Auth::user()->ban == 1): ?>
                <p style="color: red">You are banned from posting comments. For query email at info@xyz.com</p>
            <?php else: ?>

                <form method="post" action="<?php echo e(url('/topic/'.$topic->id.'/comment')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                        <input name="comment" class="form-control" placeholder="Reply to this post">
                        <span class="input-group-btn">
                            <button class="btn btn-success"><span class="fa fa-paper-plane"></span> Submit</button>
                        </span>

                    </div>
                </form>
            <?php endif; ?>

            <br/>
        </div>
    </div>
</div>

<?php else: ?>
    <h2><span class="fa fa-arrow-circle-o-left"></span> Please Add Topic</h2>
<?php endif; ?>
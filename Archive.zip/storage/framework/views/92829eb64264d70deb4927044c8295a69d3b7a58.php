<?php $__env->startSection('content'); ?>
    <div class="container">
        <div>
            <div id="topic">
                <h2>Topic Of The Day</h2>
                <h4>Some Topic</h4>
            </div>

            <div class="comments">
                <h2>Comments <span class="badge">2</span> </h2>

                <div class="media">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object" src="<?php echo e(url('/img/dp.png')); ?>" width="40px" alt="Generic placeholder image">
                        </a>
                    </div>

                    <div class="media-body">
                        <h4 class="media-heading">Arslan Asif</h4>
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.

                    </div>
                </div>

                <div class="media">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object" src="<?php echo e(url('/img/dp.png')); ?>" width="40px" alt="Generic placeholder image">
                        </a>
                    </div>

                    <div class="media-body">
                        <h4 class="media-heading">Khalid Mansoor</h4>
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
                    </div>
                </div>

                <br>
                <form method="post" action="#">
                    <div class="input-group">
                        <input class="form-control" placeholder="Reply to this post">
                        <span class="input-group-btn">
                            <button class="btn btn-default">Submit</button>
                        </span>

                    </div>
                </form>

                <br/>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
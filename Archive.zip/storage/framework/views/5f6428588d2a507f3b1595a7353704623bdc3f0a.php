<div class="navbar-header">

    <!-- Collapsed Hamburger -->
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
        <span class="sr-only">Toggle Navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>

    <!-- Branding Image -->
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <span class="fa fa-fire" style="color: red"></span>
        <?php echo e(config('app.name', 'Laravel')); ?>

    </a>
</div>

<div class="collapse navbar-collapse" id="app-navbar-collapse">

    <ul class="nav navbar-nav navbar-right" id="no-panel-links">
        <!-- Authentication Links -->
        <?php if(Auth::guest()): ?>
            <li><a href="<?php echo e(url('/login')); ?>"><span class="fa fa-user"></span> Login</a></li>
        <?php else: ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="fa fa-user-secret"></span>
                    <?php echo e(Auth::user()->name); ?> <span class="fa fa-caret-down"></span>
                </a>

                <ul class="dropdown-menu" role="menu">
                    <li>
                        <?php if(Auth::user()->is_admin): ?>
                            <a href="<?php echo e(url('/admin')); ?>">
                                <span class="fa fa-line-chart"></span>
                                Admin Panel
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/logout')); ?>"
                           onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                            <span class="fa fa-sign-out"></span>
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
    </ul>

    <!-- Right Side Of Navbar -->
    <ul class="nav navbar-nav navbar-right" id="panel-links">
        <!-- Authentication Links -->
        <?php if(Auth::guest()): ?>
            <li><a href="<?php echo e(url('/login')); ?>"><span class="fa fa-user"></span> Login</a></li>
        <?php else: ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <span class="fa fa-user-secret"></span>
                    <?php echo e(Auth::user()->name); ?> <span class="fa fa-caret-down"></span>
                </a>

                <ul class="dropdown-menu" role="menu">
                    <li>
                        <?php if(Auth::user()->is_admin): ?>
                            <a href="<?php echo e(url('/admin')); ?>">
                                <span class="fa fa-line-chart"></span>
                                Admin Panel
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/logout')); ?>"
                           onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                            <span class="fa fa-sign-out"></span>
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>

            <?php if(Auth::user()->is_admin): ?>
                <?php echo $__env->make('includes.admin_links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</div>
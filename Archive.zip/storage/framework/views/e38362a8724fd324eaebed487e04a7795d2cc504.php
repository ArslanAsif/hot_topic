<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(isset($message)): ?>
            <div class="col-md-12">
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php echo $__env->make('includes.post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<li>
    <a href="#">New topic</a>
</li>
<li>
    <a href="#">Edit topic</a>
</li>
<li>
    <a href="#">Previous Topics</a>
</li>
<li>
    <a href="#">All User</a>
</li>
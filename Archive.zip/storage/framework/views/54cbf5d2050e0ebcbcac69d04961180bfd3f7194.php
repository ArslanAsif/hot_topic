<?php $__env->startSection('content'); ?>
    <div>
        <h2>
            <?php if(isset($topic)): ?>
                <span class="fa fa-pencil"></span> Edit Topic
            <?php else: ?>
                <span class="fa fa-pencil-square-o"></span> New Topic
            <?php endif; ?>
        </h2>

        <form method="post" action="#">
            <?php echo e(csrf_field()); ?>

            <textarea name="title" class="form-control" rows="3" placeholder="Enter topic description"> <?php if(isset($topic)): ?> <?php echo e($topic->title); ?> <?php endif; ?></textarea>
            </br>
            <button class="btn btn-default" type="submit"><span class="fa fa-paper-plane"></span> Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>